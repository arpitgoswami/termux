from setuptools import setup
setup (
name = 'death',
version = '1.0',
description = 'my new python module',
author = 'Arpit',
author_email = 'anonymous@loonycorn.com',
url = 'loony.com',
py_modules = ['death']
)
