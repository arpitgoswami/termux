def death(a, b, c):
    print(20, end="")
    print(c + (b+a))
    return
