def add(a, b):
    sum = a + b
    print(sum)
    return
